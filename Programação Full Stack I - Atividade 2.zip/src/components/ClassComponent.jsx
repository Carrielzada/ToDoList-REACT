import React, { Component } from 'react';
import './css/ClassComponent.css'; // Importe o arquivo de estilos do componente
import Filter from "./Filter"; // Importe o componente Filter
import Search from "./Search"; // Importe o componente Search
import Todo from "./Todo"; // Importe o componente Todo
import TodoForm from "./TodoForm"; // Importe o componente TodoForm

class ClassComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fontSize: 16, // Tamanho inicial da fonte
    };
  }

  increaseFontSize = () => {
    this.setState((prevState) => ({
      fontSize: prevState.fontSize + 2, // Aumenta o tamanho da fonte em 2 unidades
    }));
  };

  decreaseFontSize = () => {
    this.setState((prevState) => ({
      fontSize: prevState.fontSize - 2, // Diminui o tamanho da fonte em 2 unidades
    }));
  };

  render() {
    const { fontSize } = this.state;

    return (
      <div className="class-component">
        {/* Botões para aumentar e diminuir o tamanho da fonte */}
        <button onClick={this.increaseFontSize}>Aumentar Fonte</button>
        <button onClick={this.decreaseFontSize}>Diminuir Fonte</button>

        {/* Elementos de texto com o tamanho da fonte controlado pelo estado fontSize */}
        <h1 style={{ fontSize: `${fontSize}px` }}>Exemplo de Título</h1>
        <p style={{ fontSize: `${fontSize}px` }}>Exemplo de Parágrafo</p>
        
        {/* Outros componentes */}
        <Filter />
        <Search />
        <Todo />
        <TodoForm />
        {/* Adicione outros componentes conforme necessário */}
      </div>
    );
  }
}

export default ClassComponent;
